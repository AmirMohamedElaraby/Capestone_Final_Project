﻿using System;
using System.ComponentModel.DataAnnotations;

public class AddressAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value is string address)
        {
            // Perform custom validation logic here
            // For example, check if the address is not empty and meets certain criteria
            if (string.IsNullOrWhiteSpace(address))
            {
                return new ValidationResult("Address cannot be empty.");
            }

            // Example: Check for a minimum length
            if (address.Length < 5)
            {
                return new ValidationResult("Address must be at least 5 characters long.");
            }

            // You can add more complex validation logic here if needed

            return ValidationResult.Success;
        }

        return new ValidationResult("Invalid address format.");
    }
}