﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Models
{
    public class Order
    {
        public int Id { get; set; }  // Unique Order ID

        [Required]
        public int UserId { get; set; }  // Links to the User

        public User User { get; set; }  // Navigation property

        [Required]
        public decimal TotalPrice { get; set; }  // Sum of all items

        [Required]
        public string Status { get; set; } = "Pending";  // Pending, Shipped, Delivered


        [Required]
        public string ShippingAddress { get; set; } = string.Empty;  // Where the order will be sent

        [Required]
        public string BillingAddress { get; set; } = string.Empty;  // For payment processing

        public string? PhoneNumber { get; set; }  // Contact for delivery updates

        public DateTime OrderDate { get; set; } = DateTime.UtcNow;  // Order placement date

        public List<OrderItem> OrderItems { get; set; } = new List<OrderItem>();  // List of items

        public Payment? Payment { get; set; }  // Payment details
    }
}
