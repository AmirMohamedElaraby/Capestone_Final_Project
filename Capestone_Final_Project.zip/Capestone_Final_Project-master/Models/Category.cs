﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Models
{
    public class Category
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        // Relationship:A category have many products
        public ICollection<Product> Products { get; set; }
    }
}
