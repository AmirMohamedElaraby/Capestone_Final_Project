﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Models
{
    public class Payment
    {
        public int Id { get; set; }  // Internal system ID

        [Required]
        public int OrderId { get; set; }  // Links to the Order

        public Order Order { get; set; }  // Navigation property

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string PaymentMethod { get; set; } = string.Empty;  // e.g., "Credit Card", "PayPal"

        public string? TransactionId { get; set; }  // Unique reference from payment gateway

        [Required]

        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
    }
}
