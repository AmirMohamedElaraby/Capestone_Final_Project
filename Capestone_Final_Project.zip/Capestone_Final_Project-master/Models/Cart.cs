﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Capestone_Final_Project.Models
{
    public class Cart
    {
        public int Id { get; set; }  // Unique identifier

        [Required]
        public int UserId { get; set; } // Links cart to user

        public List<CartItem> CartItems { get; set; } = new List<CartItem>(); // List of cart items

        [NotMapped] // Prevents storing this in the database
        public decimal TotalPrice => CartItems.Sum(item => item.Quantity * item.Price); // Auto-calculated
        public User user { get; set; }
        public ICollection<CartItem> cartItems { get; set; }
    }
}
