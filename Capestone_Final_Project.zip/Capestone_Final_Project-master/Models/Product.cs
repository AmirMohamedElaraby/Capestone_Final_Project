﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than zero.")]
        public decimal Price { get; set; }

        public string? Description { get; set; }

        [Required]
        public int CategoryId { get; set; } // Foreign key

        public Category Category { get; set; } // Navigation property

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Stock must be zero or greater.")]
        public int StockQuantity { get; set; }

        public string? ImageUrl { get; set; } // Optional image URL

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public ICollection<CartItem> cartItems { get; set; }
        public ICollection<OrderItem> orderItems { get; set; }
    }
}
