﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Models
{
    public class OrderItem
    {
            [Key]
            public int Id { get; set; } // Unique identifier

            [Required]
            public int OrderId { get; set; } // Links to an Order

            [Required]
            public int ProductId { get; set; } // Links to a Product

            [Required]
            [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
            public int Quantity { get; set; } // Number of units

            [Required]
            [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than zero.")]
            public decimal Price { get; set; } // Price per unit
            public Order order { get; set; }
            public Product product { get; set; }
    }
}
