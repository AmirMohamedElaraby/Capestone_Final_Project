﻿using Capestone_Final_Project.Dtos.CartItemDtos;
using System.ComponentModel.DataAnnotations.Schema;

namespace Capestone_Final_Project.Dtos.CartDtos
{
    public class CartDto
    {
        public int Id { get; set; }  // Unique identifier

        public int UserId { get; set; } // Links cart to user

        public List<CartItemOnlyDto> CartItems { get; set; } = new List<CartItemOnlyDto>(); // List of cart items

        [NotMapped] // Prevents storing this in the database
        public decimal TotalPrice => CartItems.Sum(item => item.Quantity * item.Price); // Auto-calculated
    }
}
