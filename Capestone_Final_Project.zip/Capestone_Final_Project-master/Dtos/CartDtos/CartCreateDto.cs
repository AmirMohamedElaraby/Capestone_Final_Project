﻿using Capestone_Final_Project.Dtos.CartItemDtos;
using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Dtos.CartDtos
{
    public class CartCreateDto
    {
        [Required]
        public int UserId { get; set; }  // Links cart to user

        public List<CartItemOnlyDto> CartItems { get; set; } = new List<CartItemOnlyDto>();
    }
}
