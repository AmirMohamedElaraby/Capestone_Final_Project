﻿using Capestone_Final_Project.Dtos.OrderItemDtos;
using Capestone_Final_Project.Dtos.PaymentDtos;

namespace Capestone_Final_Project.Dtos.OrderDtos
{
    public class OrderDto
    {
        
            public int Id { get; set; }  // Unique Order ID

            //public int UserId { get; set; }  // Links to the User

            public decimal TotalPrice { get; set; }  // Sum of all items

            public string Status { get; set; } = "Pending";  // Order status

            public string ShippingAddress { get; set; } = string.Empty;  // Shipping address

            public string BillingAddress { get; set; } = string.Empty;  // Billing address

            public string? PhoneNumber { get; set; }  // Contact number

            public DateTime OrderDate { get; set; }  // Order placement date

            public List<OrderItemDtoForOrder> OrderItems { get; set; } = new List<OrderItemDtoForOrder>();  // List of items
            public PaymentOnlyDto paymentdto { get; set; }
    }
}
