﻿using Capestone_Final_Project.Dtos.OrderItemDtos;
using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Dtos.OrderDtos
{
    public class OrderCreateDto
    {
        
            [Required]
            public int UserId { get; set; }  // Links to the User

            [Required]
            public decimal TotalPrice { get; set; }  // Sum of all items

            [Required]
            public string ShippingAddress { get; set; } = string.Empty;  // Shipping address

            [Required]
            public string BillingAddress { get; set; } = string.Empty;  // Billing address

            public string? PhoneNumber { get; set; }  // Contact number for updates

            public List<OrderItemDtoForOrder> OrderItems { get; set; } = new List<OrderItemDtoForOrder>();  // List of items
        
    }
}
