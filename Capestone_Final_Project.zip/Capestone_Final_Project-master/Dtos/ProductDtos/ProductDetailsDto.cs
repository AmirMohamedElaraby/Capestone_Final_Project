﻿using Capestone_Final_Project.Dtos.CategoryDtos;
using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Dtos.ProductDtos
{
    public class ProductDetailsDto
    {
        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than zero.")]
        public decimal Price { get; set; }
        public string? ImageUrl { get; set; } // Optional image URL
        public DateTime CreatedAt { get; set; }
        public string? Description { get; set; }
        public CategoryForProductDto dtoCP { get; set; }
    }
}
