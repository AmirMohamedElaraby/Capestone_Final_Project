﻿using Capestone_Final_Project.Dtos.OrderDtos;

namespace Capestone_Final_Project.Dtos.UserDtos
{
    public class UserDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public ICollection<OrderDto> ordersdto { get; set; }
    }
}
