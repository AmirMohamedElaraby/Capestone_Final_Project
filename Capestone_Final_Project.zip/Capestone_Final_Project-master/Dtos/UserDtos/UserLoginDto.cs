﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Dtos.UserDtos
{
    public class UserLoginDto
    {
        [Required]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(12, MinimumLength = 8, ErrorMessage = "Password must be between 8 and 12 characters.")]
        public string Password { get; set; }
    
    }
}
