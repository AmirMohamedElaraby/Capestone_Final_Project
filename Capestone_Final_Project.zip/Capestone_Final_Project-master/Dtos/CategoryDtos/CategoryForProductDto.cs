﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Dtos.CategoryDtos
{
    public class CategoryForProductDto
    {
        [Required]
        public string Name { get; set; } 
    }
}
