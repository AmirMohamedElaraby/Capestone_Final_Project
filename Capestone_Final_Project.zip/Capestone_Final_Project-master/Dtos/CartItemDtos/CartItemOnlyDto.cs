﻿namespace Capestone_Final_Project.Dtos.CartItemDtos
{
    public class CartItemOnlyDto
    {
        public int ProductId { get; set; }  // ID of the product

        public int Quantity { get; set; }  // Quantity of the product

        public decimal Price { get; set; }  // Price of the product
    }
}
