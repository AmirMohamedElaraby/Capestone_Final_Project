﻿using System.ComponentModel.DataAnnotations;

namespace Capestone_Final_Project.Dtos.PaymentDtos
{
    public class PaymentOnlyDto
    {
        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string PaymentMethod { get; set; } = string.Empty;  // e.g., "Credit Card", "PayPal"

        public string? TransactionId { get; set; }  // Unique reference from payment gateway

        [Required]

        public DateTime PaymentDate { get; set; } 
    }
}
